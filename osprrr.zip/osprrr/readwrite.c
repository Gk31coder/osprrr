#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

/* shared state */
pthread_mutex_t lock       = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  can_read   = PTHREAD_COND_INITIALIZER;
pthread_cond_t  can_write  = PTHREAD_COND_INITIALIZER;

int  buff          = 0;  /* shared buffer */
int  read_count    = 0;  /* active readers */
int  writer_active = 0;  /* flag: writer working */

void *reader(void *arg);
void *writer(void *arg);
int   writebuff(void);
void  readbuff(int buffer);

/* ---------------- Reader thread ---------------- */
void *reader(void *arg)
{
    while (1) {
        pthread_mutex_lock(&lock);

        /* wait while a writer is active */
        while (writer_active)
            pthread_cond_wait(&can_read, &lock);

        read_count++;
        pthread_mutex_unlock(&lock);

        /* ---- critical section (reading) ---- */
        readbuff(buff);
        usleep(500000);   /* simulate reading time */
        /* ------------------------------------ */

        pthread_mutex_lock(&lock);
        read_count--;
        if (read_count == 0)
            pthread_cond_signal(&can_write); /* last reader wakes writers */
        pthread_mutex_unlock(&lock);

        usleep(100000); /* let others run */
    }
    return NULL;
}

/* ---------------- Writer thread ---------------- */
void *writer(void *arg)
{
    while (1) {
        pthread_mutex_lock(&lock);

        /* wait until no readers and no other writer */
        while (read_count > 0 || writer_active)
            pthread_cond_wait(&can_write, &lock);

        writer_active = 1;
        pthread_mutex_unlock(&lock);

        /* ---- critical section (writing) ---- */
        buff = writebuff();
        usleep(200000);   /* simulate writing time */
        /* ------------------------------------ */

        pthread_mutex_lock(&lock);
        writer_active = 0;
        pthread_cond_broadcast(&can_read);  /* wake all readers first */
        pthread_cond_signal(&can_write);    /* then next writer */
        pthread_mutex_unlock(&lock);

        usleep(100000);
    }
    return NULL;
}

/* ---------------- Helper functions ---------------- */
int writebuff(void)
{
    int wv;
    printf("Writer: Enter a value to write in buffer: ");
    fflush(stdout);
    scanf("%d", &wv);
    return wv;
}

void readbuff(int buffer)
{
    printf("Reader is reading value = %d\n", buffer);
}

/* ---------------- Main ---------------- */
int main(void)
{
    pthread_t r1, r2, w1;

    pthread_create(&r1, NULL, reader, NULL);
    pthread_create(&r2, NULL, reader, NULL);
    pthread_create(&w1, NULL, writer, NULL);

    pthread_join(r1, NULL);
    pthread_join(r2, NULL);
    pthread_join(w1, NULL);

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&can_read);
    pthread_cond_destroy(&can_write);

    return 0;
}
/*
gayulap@gayulap-VirtualBox:~/Desktop$ gcc readwrite.c
gayulap@gayulap-VirtualBox:~/Desktop$ ./a.out
Reader is reading value = 0
Reader is reading value = 0
Writer: Enter a value to write in buffer: 78
Reader is reading value = 78
Reader is reading value = 78
Writer: Enter a value to write in buffer: 12
Reader is reading value = 12
Reader is reading value = 12
Writer: Enter a value to write in buffer: 70
Reader is reading value = 70
Reader is reading value = 70
Writer: Enter a value to write in buffer: 34
Reader is reading value = 34
Reader is reading value = 34
Writer: Enter a value to write in buffer: 

*/

#include <stdio.h>
#include <stdlib.h>

void binser(int arr[], int left, int right, int ele);

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("No array provided to search.\n");
        return 1;
    }

    // Convert command-line arguments to integers and store in arr[]
    int arr[30];
    int size = argc - 1;  // The first argument is the program name, rest are array elements
    for (int i = 0; i < size; i++) {
        arr[i] = atoi(argv[i + 1]);
    }

    // Print the sorted array received from the parent process
    printf("after sorting\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Ask user for the element to search
    int ele;
    printf("Enter the element to be searched: ");
    scanf("%d", &ele);

    // Perform binary search
    binser(arr, 0, size - 1, ele);

    return 0;
}

// Binary search function
void binser(int arr[], int left, int right, int ele) {
    int mid;
    while (left <= right) {
        mid = (left + right) / 2;

        if (arr[mid] < ele) {
            left = mid + 1;
        } else if (arr[mid] == ele) {
            printf("\nElement %d found at %d location\n", ele, mid + 1);
            return;
        } else {
            right = mid - 1;
        }
    }

    printf("\nElement %d not found in the array\n", ele);
}


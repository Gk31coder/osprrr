#!/bin/bash

emp_name=-1
emp_city=-1
emp_code=-1
emp_mobno=-1
n=0
ch=0

while [ $ch -ne 6 ]
do
  echo -e "\n=== Employee Database Menu ==="
  echo "1. Create New Employee Database"
  echo "2. View Employee Database"
  echo "3. Insert New Employee Record"
  echo "4. Delete Employee Record"
  echo "5. Modify Employee Record"
  echo "6. Exit"
  echo -n "Enter your choice: "
  read ch
  case $ch in
    1) # Create Employee Database
      echo -n "Enter file name: "
      read fname
      touch "$fname"
      echo "Enter the number of records to be entered in file $fname:"
      read n
      i=$n
      while [ $i -gt 0 ]
      do
        echo -n "Enter employee name: "
        read emp_name
        echo -n "Enter City: "
        read emp_city
        echo -n "Enter Employee ID (e.g. 101): "
        read emp_code
        echo -n "Enter Mobile no.: "
        read emp_mobno
        echo "$emp_name|$emp_city|$emp_code|$emp_mobno" >> "$fname"
        echo "Your data is stored in the file."
        i=$((i-1))
      done
      ;;
      
    2) # View Employee Database
      if [ -f "$fname" ]; then
        cat "$fname"
      else
        echo "File not found. Create database first!"
      fi
      ;;
      
    3) # Insert New Employee Record
      echo -n "Enter employee name: "
      read emp_name
      echo "Enter City: "
      read emp_city
      echo "Enter Employee ID: "
      read emp_code
      echo "Enter Mobile no.: "
      read emp_mobno
      echo "$emp_name|$emp_city|$emp_code|$emp_mobno" >> "$fname"
      echo "Record inserted successfully."
      ;;
      
    4) # Delete Employee Record
      echo -n "Enter the name of the employee record to be deleted: "
      read emp_name
      if grep -w "$emp_name" "$fname" > /dev/null; then
        grep -w -v "$emp_name" "$fname" > temp
        mv temp "$fname"
        echo "Record deleted successfully!"
      else
        echo "Record not found."
      fi
      ;;
      
    5) # Modify Employee Record
      echo -n "Enter the name of the employee record to be modified: "
      read emp_name
      if grep -w "$emp_name" "$fname" > /dev/null; then
        grep -w -v "$emp_name" "$fname" > temp
        echo -n "Enter new employee name: "
        read emp_name
        echo "Enter new City: "
        read emp_city
        echo "Enter new Employee ID: "
        read emp_code
        echo "Enter new Mobile no.: "
        read emp_mobno
        echo "$emp_name|$emp_city|$emp_code|$emp_mobno" >> temp
        mv temp "$fname"
        echo "Record modified successfully."
      else
        echo "Record not found!"
      fi
      ;;
      
    6) # Exit
      echo -n "Exiting the program. Goodbye!"
      ;;
      
    *) # Invalid Choice
      echo "Invalid choice. Please enter a number between 1 and 6."
      ;;
  esac
done


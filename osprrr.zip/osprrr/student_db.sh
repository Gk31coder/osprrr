#!/bin/bash

stud_name=-1
stud_city=-1
stud_roll=-1
stud_mobno=-1
n=0
ch=0

while [ $ch -ne 6 ]
do
  echo -e "\n=== Student Database Menu ==="
  echo "1. Create New Student Database"
  echo "2. View Student Database"
  echo "3. Insert New Student Record"
  echo "4. Delete Student Record"
  echo "5. Modify Student Record"
  echo "6. Exit"
  echo -n "Enter your choice: "
  read ch

  case $ch in
    1) # Create Student Database
      echo -n "Enter file name: "
      read fname
      touch "$fname"
      echo "Enter the number of student records to be entered in file $fname:"
      read n
      i=$n
      while [ $i -gt 0 ]
      do
        echo -n "Enter Student Name: "
        read stud_name
        echo -n "Enter City: "
        read stud_city
        echo -n "Enter Roll No: "
        read stud_roll
        echo -n "Enter Mobile No: "
        read stud_mobno
        echo "$stud_name|$stud_city|$stud_roll|$stud_mobno" >> "$fname"
        echo "Record stored successfully."
        i=$((i-1))
      done
      ;;
      
    2) # View Student Database
      if [ -f "$fname" ]; then
        echo -e "\n--- Student Database ---"
        cat "$fname"
      else
        echo "File not found! Create database first."
      fi
      ;;
      
    3) # Insert New Student Record
      echo -n "Enter Student Name: "
      read stud_name
      echo -n "Enter City: "
      read stud_city
      echo -n "Enter Roll No: "
      read stud_roll
      echo -n "Enter Mobile No: "
      read stud_mobno
      echo "$stud_name|$stud_city|$stud_roll|$stud_mobno" >> "$fname"
      echo "Record inserted successfully."
      ;;
      
    4) # Delete Student Record
      echo -n "Enter the Student Name to delete: "
      read stud_name
      if grep -w "$stud_name" "$fname" > /dev/null; then
        grep -w -v "$stud_name" "$fname" > temp
        mv temp "$fname"
        echo "Record deleted successfully."
      else
        echo "Record not found!"
      fi
      ;;
      
    5) # Modify Student Record
      echo -n "Enter the Student Name to modify: "
      read stud_name
      if grep -w "$stud_name" "$fname" > /dev/null; then
        grep -w -v "$stud_name" "$fname" > temp
        echo -n "Enter new Student Name: "
        read stud_name
        echo -n "Enter new City: "
        read stud_city
        echo -n "Enter new Roll No: "
        read stud_roll
        echo -n "Enter new Mobile No: "
        read stud_mobno
        echo "$stud_name|$stud_city|$stud_roll|$stud_mobno" >> temp
        mv temp "$fname"
        echo "Record modified successfully."
      else
        echo "Record not found!"
      fi
      ;;
      
    6) # Exit
      echo "Exiting the program. Goodbye!"
      ;;
      
    *) # Invalid Choice
      echo "Invalid choice! Please enter a number between 1 and 6."
      ;;
  esac
done

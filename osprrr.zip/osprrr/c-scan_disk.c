#include <stdio.h> 
#include <stdlib.h> 
 
int main() {     
    int n, i, j, head, total_movement = 0, disk_size, direction, index;     
    printf("Enter number of disk requests: ");     
    scanf("%d", &n); 

    int requests[n];     
    printf("Enter the request sequence: ");     
    for (i = 0; i < n; i++)         
        scanf("%d", &requests[i]); 

    printf("Enter initial head position: ");     
    scanf("%d", &head); 

    printf("Enter total disk size: ");     
    scanf("%d", &disk_size); 

    printf("Enter head movement direction (1 for high/right, 0 for low/left): ");     
    scanf("%d", &direction); 

    // Add boundaries     
    int size = n + 2;     
    int arr[size];     
    for (i = 0; i < n; i++)         
        arr[i] = requests[i];     
    arr[n] = 0;     
    arr[n + 1] = disk_size - 1; 

    // Sort requests     
    for (i = 0; i < size - 1; i++) {         
        for (j = i + 1; j < size; j++) {             
            if (arr[i] > arr[j]) {                 
                int temp = arr[i];                 
                arr[i] = arr[j];                 
                arr[j] = temp;             
            }         
        }     
    } 

    // Find head index     
    for (i = 0; i < size; i++) {         
        if (head < arr[i]) {             
            index = i;             
            break;         
        }     
    } 

    printf("\nSeek Sequence: %d", head); 

    if (direction == 1) {  // Move toward higher track numbers         
        for (i = index; i < size; i++) {             
            total_movement += abs(head - arr[i]);             
            head = arr[i];             
            printf("  %d", head);         
        }         
        // Jump to beginning         
        total_movement += abs(disk_size - 1 - 0);         
        head = 0;         
        printf("  0"); 

        for (i = 0; i < index; i++) {             
            total_movement += abs(head - arr[i]);             
            head = arr[i];             
            printf("  %d", head);         
        }     
    } else {  // Move toward lower track numbers         
        for (i = index - 1; i >= 0; i--) {             
            total_movement += abs(head - arr[i]);             
            head = arr[i];             
            printf("  %d", head);         
        }         
        // Jump to end         
        total_movement += abs((disk_size - 1) - 0);         
        head = disk_size - 1;         
        printf("  %d", head); 

        for (i = size - 2; i >= index; i--) {             
            total_movement += abs(head - arr[i]);             
            head = arr[i];             
            printf("  %d", head);         
        }     
    } 

    printf("\n\nTotal Head Movement: %d", total_movement);     
    printf("\nAverage Seek Time: %.2f\n", (float)total_movement / n); 
 
    return 0; 
}

/*
output:-

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc c-scan_disk.c
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./a.out
Enter number of disk requests: 8
Enter the request sequence: 98 183 37 122 14 124 65 67
Enter initial head position: 53
Enter total disk size: 200
Enter head movement direction (1 for high/right, 0 for low/left): 0

Seek Sequence: 53  37  14  0  199  183  124  122  98  67  65

Total Head Movement: 386
Average Seek Time: 48.25
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc c-scan_disk.c
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./a.out
Enter number of disk requests: 8 
Enter the request sequence: 98 183 37 122 14 124 65 67
Enter initial head position: 53
Enter total disk size: 200
Enter head movement direction (1 for high/right, 0 for low/left): 1

Seek Sequence: 53  65  67  98  122  124  183  199  0  0  14  37

Total Head Movement: 382
Average Seek Time: 47.75
*/

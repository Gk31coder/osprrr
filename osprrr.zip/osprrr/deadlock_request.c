#include <stdio.h>

void main()
{
    int n, m, i, j, instance, k = 0, count = 0, temp = 0;
    printf("Enter the number of processes: ");
    scanf("%d", &n);
    printf("Enter the number of resources: ");
    scanf("%d", &m);

    int alloc[n][m];  // Allocation matrix
    int max[n][m];    // Maximum matrix
    int avail[m];     // Available resources
    int need[n][m];   // Need matrix (max - allocation)
    int completed[n]; // To track which processes are completed

    for(i = 0; i < n; i++)
        completed[i] = 0;

    // Input for available resources
    printf("Enter the available resources for processes:\n");
    for (i = 0; i < m; i++) {
        printf("Resources[%d]:", i);
        scanf("%d", &instance);
        avail[i] = instance;
    }

    // Input for max matrix
    printf("\n-----------------------------------------------\n");
    printf("Enter the max matrix for process:\n");
    for (i = 0; i < n; i++) {
        printf("\nFor Process[%d]\n", i);
        for (j = 0; j < m; j++) {
            printf("Resource[%d]:", j);
            scanf("%d", &instance);
            max[i][j] = instance;
        }
    }

    // Input for allocation matrix
    printf("\n-----------------------------------------------\n");
    printf("Enter the allocation matrix:\n");
    for (i = 0; i < n; i++) {
        printf("\nFor Process[%d]\n", i);
        for (j = 0; j < m; j++) {
            printf("Resource[%d]:", j);
            scanf("%d", &instance);
            alloc[i][j] = instance;
            need[i][j] = max[i][j] - alloc[i][j]; // Calculate the need matrix
        }
    }

    // Request Algorithm
    printf("\n-----------------------------------------------\n");
    printf("Request Algorithm\n");
    printf("Enter the process number that is requesting resources:");
    int rp;
    scanf("%d", &rp);

    printf("Enter the resources requested by the process:\n");
    int rr[m];
    for(i = 0; i < m; i++){
        printf("Resource[%d]:", i);
        scanf("%d", &instance);
        rr[i] = instance;
    }

    // Check if the request can be granted
    int canGrant = 1;
    for(i = 0; i < m; i++){
        if(rr[i] > need[rp][i]) {
            canGrant = 0; // Request exceeds need
            break;
        }
    }

    if(canGrant) {
        // Check if the system has enough resources to grant the request
        for(i = 0; i < m; i++){
            if(rr[i] > avail[i]) {
                canGrant = 0; // Not enough resources available
                break;
            }
        }
    }

    if(canGrant) {
        // Grant the request
        for(i = 0; i < m; i++) {
            avail[i] -= rr[i];
            alloc[rp][i] += rr[i];
            need[rp][i] -= rr[i];
        }
        printf("Request granted\n");
    } else {
        printf("Request cannot be granted\n");
    }

    // Calculate the new safe sequence
    printf("\nNew Safe Sequence is:");
    count = 0;
    temp = 0;
    for(i = 0; i < n; i++) completed[i] = 0;
    
    while(count != n) {
        temp = count;
        for(i = 0; i < n; i++) {
            int flag = 1;
            for(j = 0; j < m; j++) {
                if(need[i][j] > avail[j]) {
                    flag = 0;
                    break;
                }
            }
            if(flag && completed[i] == 0) {
                printf(" >P[%d] ", i);
                completed[i] = 1;
                for(j = 0; j < m; j++) {
                    avail[j] = avail[j] + alloc[i][j]; // Release resources
                }
                count++;
            }
        }
        if(count == temp) {
            break; // Deadlock detected (no further progress)
        }
    }

    for(i = 0; i < n; i++) {
        if(completed[i] != 1) {
            printf("\n\nP[%d] not able to allocate resources (deadlock)\n", i);
        }
    }
    printf("\n");
}
/*
gayulap@gayulap-VirtualBox:~/Desktop$ gcc deadlock_request.c
gayulap@gayulap-VirtualBox:~/Desktop$ ./a.out

Enter the number of processes: 5
Enter the number of resources: 4
Enter the available resources for processes:
Resources[0]:1
Resources[1]:5
Resources[2]:2
Resources[3]:0
-----------------------------------------------
Enter the max matrix for process:
For Process[0]
Resource[0]:0
Resource[1]:0
Resource[2]:1
Resource[3]:2
For Process[1]
Resource[0]:1
Resource[1]:7
Resource[2]:5
Resource[3]:0
For Process[2]
Resource[0]:2
Resource[1]:3
Resource[2]:5
Resource[3]:6
For Process[3]
Resource[0]:0
Resource[1]:6
Resource[2]:5
Resource[3]:2
For Process[4]
Resource[0]:0
Resource[1]:6
Resource[2]:5
Resource[3]:6
-----------------------------------------------
Enter the allocation matrix:
For Process[0]
Resource[0]:0
Resource[1]:0
Resource[2]:1
Resource[3]:2
For Process[1]
Resource[0]:1
Resource[1]:0
Resource[2]:0
Resource[3]:0
For Process[2]
Resource[0]:1
Resource[1]:3
Resource[2]:5
Resource[3]:4
For Process[3]
Resource[0]:0
Resource[1]:6
Resource[2]:3
Resource[3]:2
For Process[4]
Resource[0]:0
Resource[1]:0
Resource[2]:1
Resource[3]:4
-----------------------------------------------
Request Algorithm
Enter the process number that is requesting resources:1
Enter the resources requested by the process:
Resource[0]:0
Resource[1]:4
Resource[2]:2
Resource[3]:0
Request granted
New Safe Sequence is: > P[0] > P[2] > P[3] > P[4] > P [1]
*/


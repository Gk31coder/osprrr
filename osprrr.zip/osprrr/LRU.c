/*LRU :*/
#include <stdio.h>
int findLRU(int time[], int n) {
 int i, minimum = time[0], pos = 0;
 for (i = 1; i < n; i++) {
 if (time[i] < minimum) {
 minimum = time[i];
 pos = i;
 }
 }
 return pos;
}
int main() {
 int framesCount, pagesCount;
 int frames[10], pages[30], time[10];
 int i, j, k, pos, pageFaults = 0, counter = 0, flag1, flag2;
 printf("Enter number of frames: ");
 scanf("%d", &framesCount);
 printf("Enter number of pages: ");
 scanf("%d", &pagesCount);
 printf("Enter the page reference string: ");
 for (i = 0; i < pagesCount; i++) {
 scanf("%d", &pages[i]);
 }
 for (i = 0; i < framesCount; i++) {
 frames[i] = -1;
 }
 for (i = 0; i < pagesCount; i++) {
 flag1 = flag2 = 0;
 // Check if page is already in frame
 for (j = 0; j < framesCount; j++) {
 if (frames[j] == pages[i]) {
 counter++;
 time[j] = counter; // Update recent use
 flag1 = flag2 = 1;
 break;
 }
 }
 // If frame is empty, place page directly
 if (flag1 == 0) {
 for (j = 0; j < framesCount; j++) {
 if (frames[j] == -1) {
 counter++;
 pageFaults++;
 frames[j] = pages[i];
 time[j] = counter;
 flag2 = 1;
 break;
 }
 }
 }
 // If no empty frame, replace LRU
 if (flag2 == 0) {
 pos = findLRU(time, framesCount);
 counter++;
 pageFaults++;
 frames[pos] = pages[i];
 time[pos] = counter;
 }
 // Print current frame contents
 printf("For page %d: ", pages[i]);
 for (k = 0; k < framesCount; k++) {
 if (frames[k] == -1)
 printf(" - ");
 else
 printf(" %d ", frames[k]);
 }
 printf("\n");
 }
 printf("\nTotal Page Faults = %d\n", pageFaults);
 return 0;
}
/*
op
gayulap@gayulap-VirtualBox:~/Desktop$ gcc LRU.c
gayulap@gayulap-VirtualBox:~/Desktop$ ./a.out
Enter number of frames: 3
Enter number of pages: 
12
Enter the page reference string: 2 3 2 1 5 2 4 3 2 5 2 3
For page 2:  2  -  - 
For page 3:  2  3  - 
For page 2:  2  3  - 
For page 1:  2  3  1 
For page 5:  2  5  1 
For page 2:  2  5  1 
For page 4:  2  5  4 
For page 3:  2  3  4 
For page 2:  2  3  4 
For page 5:  2  3  5 
For page 2:  2  3  5 
For page 3:  2  3  5 

Total Page Faults = 7
*/
